# This is an auto-generated Django model module.
# You'll have to do the following manually to clean this up:
#   * Rearrange models' order
#   * Make sure each model has one field with primary_key=True
#   * Make sure each ForeignKey and OneToOneField has `on_delete` set to the desired behavior
#   * Remove `managed = False` lines if you wish to allow Django to create, modify, and delete the table
# Feel free to rename the models, but don't rename db_table values or field names.
from django.db import models


class AuthGroup(models.Model):
    name = models.CharField(unique=True, max_length=150)

    class Meta:
        managed = False
        db_table = 'auth_group'


class AuthGroupPermissions(models.Model):
    id = models.BigAutoField(primary_key=True)
    group = models.ForeignKey(AuthGroup, models.DO_NOTHING)
    permission = models.ForeignKey('AuthPermission', models.DO_NOTHING)

    class Meta:
        managed = False
        db_table = 'auth_group_permissions'
        unique_together = (('group', 'permission'),)


class AuthPermission(models.Model):
    name = models.CharField(max_length=255)
    content_type = models.ForeignKey('DjangoContentType', models.DO_NOTHING)
    codename = models.CharField(max_length=100)

    class Meta:
        managed = False
        db_table = 'auth_permission'
        unique_together = (('content_type', 'codename'),)


class AuthUser(models.Model):
    password = models.CharField(max_length=128)
    last_login = models.DateTimeField(blank=True, null=True)
    is_superuser = models.IntegerField()
    username = models.CharField(unique=True, max_length=150)
    first_name = models.CharField(max_length=150)
    last_name = models.CharField(max_length=150)
    email = models.CharField(max_length=254)
    is_staff = models.IntegerField()
    is_active = models.IntegerField()
    date_joined = models.DateTimeField()

    class Meta:
        managed = False
        db_table = 'auth_user'


class AuthUserGroups(models.Model):
    id = models.BigAutoField(primary_key=True)
    user = models.ForeignKey(AuthUser, models.DO_NOTHING)
    group = models.ForeignKey(AuthGroup, models.DO_NOTHING)

    class Meta:
        managed = False
        db_table = 'auth_user_groups'
        unique_together = (('user', 'group'),)


class AuthUserUserPermissions(models.Model):
    id = models.BigAutoField(primary_key=True)
    user = models.ForeignKey(AuthUser, models.DO_NOTHING)
    permission = models.ForeignKey(AuthPermission, models.DO_NOTHING)

    class Meta:
        managed = False
        db_table = 'auth_user_user_permissions'
        unique_together = (('user', 'permission'),)


class DjangoAdminLog(models.Model):
    action_time = models.DateTimeField()
    object_id = models.TextField(blank=True, null=True)
    object_repr = models.CharField(max_length=200)
    action_flag = models.PositiveSmallIntegerField()
    change_message = models.TextField()
    content_type = models.ForeignKey('DjangoContentType', models.DO_NOTHING, blank=True, null=True)
    user = models.ForeignKey(AuthUser, models.DO_NOTHING)

    class Meta:
        managed = False
        db_table = 'django_admin_log'


class DjangoContentType(models.Model):
    app_label = models.CharField(max_length=100)
    model = models.CharField(max_length=100)

    class Meta:
        managed = False
        db_table = 'django_content_type'
        unique_together = (('app_label', 'model'),)


class DjangoMigrations(models.Model):
    id = models.BigAutoField(primary_key=True)
    app = models.CharField(max_length=255)
    name = models.CharField(max_length=255)
    applied = models.DateTimeField()

    class Meta:
        managed = False
        db_table = 'django_migrations'


class DjangoSession(models.Model):
    session_key = models.CharField(primary_key=True, max_length=40)
    session_data = models.TextField()
    expire_date = models.DateTimeField()

    class Meta:
        managed = False
        db_table = 'django_session'


class T1Pedidos(models.Model):
    id_original = models.TextField(blank=True, null=True)
    id_produto = models.TextField(blank=True, null=True)
    id_cliente = models.TextField(blank=True, null=True)
    id_funcionario = models.TextField(blank=True, null=True)
    quantidade = models.FloatField(blank=True, null=True)
    valor_unitario = models.FloatField(blank=True, null=True)
    pedido_realizado = models.TextField(blank=True, null=True)
    pedido_aprovado = models.TextField(blank=True, null=True)
    pedido_separacao = models.TextField(blank=True, null=True)
    pedido_faturado = models.TextField(blank=True, null=True)
    pedido_coletado = models.TextField(blank=True, null=True)
    previsao_entrega = models.TextField(blank=True, null=True)
    entrega_realizada = models.TextField(blank=True, null=True)
    tempo_aprovacao = models.FloatField(blank=True, null=True)
    tempo_separacao = models.FloatField(blank=True, null=True)
    tempo_faturamento = models.FloatField(blank=True, null=True)
    tempo_coleta = models.FloatField(blank=True, null=True)
    entrega_realizada_0_field = models.FloatField(db_column='entrega_realizada_[0]', blank=True, null=True)  # Field renamed to remove unsuitable characters. Field renamed because it ended with '_'.
    entrega_realizada_1_field = models.FloatField(db_column='entrega_realizada_[1]', blank=True, null=True)  # Field renamed to remove unsuitable characters. Field renamed because it ended with '_'.
    status = models.TextField(blank=True, null=True)

    class Meta:
        managed = False
        db_table = 't1_pedidos'


class T2Leadtime(models.Model):
    processo = models.TextField(blank=True, null=True)
    tempo_dias = models.FloatField(blank=True, null=True)

    class Meta:
        managed = False
        db_table = 't2_leadtime'


class T3Transittime(models.Model):
    cidade_pedido = models.TextField(blank=True, null=True)
    uf_pedido = models.TextField(blank=True, null=True)
    regiao_pedido = models.TextField(blank=True, null=True)
    transit_time = models.FloatField(blank=True, null=True)

    class Meta:
        managed = False
        db_table = 't3_transittime'


class T4Produtos(models.Model):
    id_produto = models.TextField(blank=True, null=True)
    descricao_produto = models.TextField(blank=True, null=True)
    quantidade_estoque = models.FloatField(blank=True, null=True)
    preco_custo_unitario = models.FloatField(blank=True, null=True)
    preco_venda_unitario = models.FloatField(blank=True, null=True)

    class Meta:
        managed = False
        db_table = 't4_produtos'


class T5Clientes(models.Model):
    cliente_cnpj = models.TextField(blank=True, null=True)
    cliente_codigo = models.TextField(blank=True, null=True)
    cliente_nome = models.TextField(blank=True, null=True)
    cliente_cidade = models.TextField(blank=True, null=True)
    cliente_uf = models.TextField(blank=True, null=True)
    cliente_regiao = models.TextField(blank=True, null=True)

    class Meta:
        managed = False
        db_table = 't5_clientes'


class T6Vendedores(models.Model):
    id_funcionario = models.TextField(blank=True, null=True)
    nome_funcionario = models.TextField(blank=True, null=True)
    unidade_funcionario = models.TextField(blank=True, null=True)
    email_funcionario = models.TextField(blank=True, null=True)

    class Meta:
        managed = False
        db_table = 't6_vendedores'


class T7Ocorrencias(models.Model):
    sv_pedido = models.IntegerField()
    id_pedido = models.CharField(max_length=30, blank=True, null=True)
    id_cliente = models.IntegerField()
    cidade_ocorrencia = models.CharField(max_length=50, blank=True, null=True)
    id_produto = models.CharField(max_length=15, blank=True, null=True)
    descricao_negocio = models.CharField(max_length=50, blank=True, null=True)
    respons�vel_ocorrencia = models.CharField(max_length=50, blank=True, null=True)
    tipo_respons�vel = models.CharField(max_length=50, blank=True, null=True)
    descricao_ocorrencia = models.CharField(max_length=50, blank=True, null=True)
    data_ocorrencia = models.CharField(max_length=20, blank=True, null=True)
    respons�vel_ocorencia = models.CharField(max_length=50, blank=True, null=True)

    class Meta:
        managed = False
        db_table = 't7_ocorrencias'
