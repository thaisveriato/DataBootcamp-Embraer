from django.forms import ModelForm
from app.models import T1Pedidos, T7Ocorrencias, T8AUXDeslocamento

class PedidosForm(ModelForm):
    class Meta:
        model = T1Pedidos
        fields = ['pedido_realizado','pedido_aprovado','pedido_separacao','pedido_faturado','pedido_coletado','entrega_realizada']


class OcorrenciaForm(ModelForm):
    class Meta:
        model = T7Ocorrencias
        fields = ['id_pedido', 'id_cliente', 'cidade_ocorrencia', 'id_produto', 'descricao_negocio', 'area_responsavel_ocorrencia', 'tipo_responsavel', 'descricao_ocorrencia', 'data_ocorrencia', 'responsavel_ocorrencia']


class TransporteForm(ModelForm):
    class Meta:
        model = T8AUXDeslocamento
        fields = ['ponto_a', 'ponto_b', 'ponto_c', 'ponto_d', 'ponto_chegada', 'data_a', 'data_b', 'data_c', 'data_d', 'data_final']
