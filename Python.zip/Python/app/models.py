from django.db import models


class PedidoAndamento(models.Model):
    id = models.AutoField(primary_key=True)
    id_original = models.TextField(blank=True, null=True)
    id_produto = models.TextField(blank=True, null=True)
    pedido_realizado = models.TextField(null=True, blank=True)
    pedido_aprovado = models.TextField(null=True, blank=True)
    pedido_separacao = models.TextField(null=True, blank=True)
    pedido_faturado = models.TextField(null=True, blank=True)
    pedido_coletado = models.TextField(null=True, blank=True)
    entrega_realizada = models.TextField(null=True, blank=True)
    status = models.TextField(null=True, blank=True)
    andamento_pedido = models.CharField(max_length=50, default='Aguardando Ação')
    ordem_page = models.IntegerField(blank=True, null=True)

    class Meta:
        managed = False  # Para informar que este modelo não deve gerenciar a tabela no banco de dados
        db_table = 'vw_andamento_pedido'  # O nome da sua View no banco de dados



class T1Pedidos(models.Model):
    id = models.AutoField(primary_key=True)
    id_original = models.TextField(blank=True, null=True)
    id_produto = models.TextField(blank=True, null=True)
    id_cliente = models.TextField(blank=True, null=True)
    id_funcionario = models.TextField(blank=True, null=True)
    quantidade = models.FloatField(blank=True, null=True)
    valor_unitario = models.FloatField(blank=True, null=True)
    pedido_realizado = models.DateField(blank=True, null=True)
    pedido_aprovado = models.DateField(blank=True, null=True)
    pedido_separacao = models.DateField(blank=True, null=True)
    pedido_faturado = models.DateField(blank=True, null=True)
    pedido_coletado = models.DateField(blank=True, null=True)
    previsao_entrega = models.DateField(blank=True, null=True)
    entrega_realizada = models.DateField(blank=True, null=True)

    class Meta:
        managed = False
        db_table = 't1_pedidos'




class T8Deslocamento(models.Model):
    id = models.AutoField(primary_key=True)
    id_original = models.TextField(db_collation='utf8mb4_0900_ai_ci', blank=True, null=True)
    cliente_codigo = models.TextField(db_collation='utf8mb4_0900_ai_ci', blank=True, null=True)
    cliente_cidade = models.TextField(db_collation='utf8mb4_0900_ai_ci', blank=True, null=True)
    id_produto = models.TextField(db_collation='utf8mb4_0900_ai_ci', blank=True, null=True)
    quantidade = models.FloatField(blank=True, null=True)
    ponto_saida = models.TextField(db_column='Ponto_Saida', db_collation='utf8mb4_0900_ai_ci', blank=True, null=True)  # Field name made lowercase.
    ponto_a = models.TextField(db_column='Ponto_A', db_collation='utf8mb4_0900_ai_ci', blank=True, null=True)  # Field name made lowercase.
    ponto_b = models.TextField(db_column='Ponto_B', db_collation='utf8mb4_0900_ai_ci', blank=True, null=True)  # Field name made lowercase.
    ponto_c = models.TextField(db_column='Ponto_C', db_collation='utf8mb4_0900_ai_ci', blank=True, null=True)  # Field name made lowercase.
    ponto_d = models.TextField(db_column='Ponto_D', db_collation='utf8mb4_0900_ai_ci', blank=True, null=True)  # Field name made lowercase.
    ponto_chegada = models.TextField(db_column='Ponto_Chegada', db_collation='utf8mb4_0900_ai_ci', blank=True, null=True)  # Field name made lowercase.
    andamento_pedido = models.CharField(max_length=19, db_collation='utf8mb4_0900_ai_ci')
    data_a = models.DateField(db_column='Data_A', blank=True, null=True)  # Field name made lowercase.
    data_b = models.DateField(db_column='Data_B', blank=True, null=True)  # Field name made lowercase.
    data_c = models.DateField(db_column='Data_C', blank=True, null=True)  # Field name made lowercase.
    data_d = models.DateField(db_column='Data_D', blank=True, null=True)  # Field name made lowercase.
    data_final = models.DateField(db_column='Data_Final', blank=True, null=True)  # Field name made lowercase.

    class Meta:
        managed = False
        db_table = 't8_deslocamento'


class T7Ocorrencias(models.Model):
     id = models.AutoField(primary_key=True)
     id_pedido = models.FloatField(blank=True, null=True)
     id_cliente = models.TextField(blank=True, null=True)
     cidade_ocorrencia = models.TextField(blank=True, null=True)
     id_produto = models.TextField(blank=True, null=True)
     descricao_negocio = models.TextField(blank=True, null=True)
     area_responsavel_ocorrencia = models.TextField(blank=True, null=True)
     tipo_responsavel = models.TextField(blank=True, null=True)
     descricao_ocorrencia = models.TextField(blank=True, null=True)
     data_ocorrencia = models.DateField(blank=True, null=True)
     responsavel_ocorrencia = models.TextField(blank=True, null=True)

     class Meta:
          managed = False
          db_table = 't7_ocorrencias'

class VWInfoWeb(models.Model):
      id = models.AutoField(primary_key=True)
      id_original = models.IntegerField(blank=True, null=True)
      cliente_codigo = models.IntegerField(blank=True, null=True)
      cliente_cidade = models.TextField(blank=True, null=True)
      id_produto = models.IntegerField(blank=True, null=True)
      quantidade = models.IntegerField(blank=True, null=True)
      Ponto_Saida = models.TextField(blank=True, null=True)
      Ponto_A = models.TextField(blank=True, null=True)
      Data_A = models.DateField(blank=True, null=True)
      Ponto_B = models.TextField(blank=True, null=True)
      Data_B = models.DateField(blank=True, null=True)
      Ponto_C = models.TextField(blank=True, null=True)
      Data_C = models.DateField(blank=True, null=True)
      Ponto_D = models.TextField(blank=True, null=True)
      Data_D = models.DateField(blank=True, null=True)
      Ponto_Chegada = models.TextField(blank=True, null=True)
      Data_Final = models.DateField(blank=True, null=True)
      andamento_pedido = models.TextField(blank=True, null=True)
      Deslocamento = models.TextField(blank=True, null=True)
      info_parada = models.IntegerField(blank=True, null=True)

      class Meta:
         managed = False
         db_table = 'VW_INFO_WEB'

class T3Transittime(models.Model):
    id = models.AutoField(primary_key=True)
    Cidade = models.TextField(blank=True, null=True)  # Field name made lowercase.
    UF = models.TextField(blank=True, null=True)  # Field name made lowercase.
    Regiao = models.TextField(blank=True, null=True)  # Field name made lowercase.
    metrica_tempo = models.IntegerField(blank=True, null=True)
    Ponto_Saida = models.TextField(blank=True, null=True)  # Field name made lowercase.
    Ponto_A = models.TextField(blank=True, null=True)  # Field name made lowercase.
    Ponto_B = models.TextField(blank=True, null=True)  # Field name made lowercase.
    Ponto_C = models.TextField(blank=True, null=True)  # Field name made lowercase.
    Ponto_D = models.TextField(blank=True, null=True)  # Field name made lowercase.
    Ponto_Chegada = models.TextField(blank=True, null=True)  # Field name made lowercase.
    info_parada = models.IntegerField(blank=True, null=True)

    class Meta:
         managed = False
         db_table = 't3_transittime'

class T8AUXDeslocamento(models.Model):
    id = models.AutoField(primary_key=True)
    id_original = models.TextField(db_collation='utf8mb4_0900_ai_ci', blank=True, null=True)
    cliente_codigo = models.TextField(db_collation='utf8mb4_0900_ai_ci', blank=True, null=True)
    cliente_cidade = models.TextField(db_collation='utf8mb4_0900_ai_ci', blank=True, null=True)
    id_produto = models.TextField(db_collation='utf8mb4_0900_ai_ci', blank=True, null=True)
    quantidade = models.FloatField(blank=True, null=True)
    ponto_saida = models.TextField(db_column='Ponto_Saida', db_collation='utf8mb4_0900_ai_ci', blank=True, null=True)  # Field name made lowercase.
    ponto_a = models.TextField(db_column='Ponto_A', db_collation='utf8mb4_0900_ai_ci', blank=True, null=True)  # Field name made lowercase.
    ponto_b = models.TextField(db_column='Ponto_B', db_collation='utf8mb4_0900_ai_ci', blank=True, null=True)  # Field name made lowercase.
    ponto_c = models.TextField(db_column='Ponto_C', db_collation='utf8mb4_0900_ai_ci', blank=True, null=True)  # Field name made lowercase.
    ponto_d = models.TextField(db_column='Ponto_D', db_collation='utf8mb4_0900_ai_ci', blank=True, null=True)  # Field name made lowercase.
    ponto_chegada = models.TextField(db_column='Ponto_Chegada', db_collation='utf8mb4_0900_ai_ci', blank=True, null=True)  # Field name made lowercase.
    andamento_pedido = models.CharField(max_length=19, db_collation='utf8mb4_0900_ai_ci')
    data_a = models.DateField(db_column='Data_A', blank=True, null=True)  # Field name made lowercase.
    data_b = models.DateField(db_column='Data_B', blank=True, null=True)  # Field name made lowercase.
    data_c = models.DateField(db_column='Data_C', blank=True, null=True)  # Field name made lowercase.
    data_d = models.DateField(db_column='Data_D', blank=True, null=True)  # Field name made lowercase.
    data_final = models.DateField(db_column='Data_Final', blank=True, null=True)  # Field name made lowercase.

    class Meta:
        managed = False
        db_table = 't8_aux_deslocamento'