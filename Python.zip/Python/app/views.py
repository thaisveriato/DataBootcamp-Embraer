from django.shortcuts import render, get_object_or_404, redirect
from app.models import PedidoAndamento, T1Pedidos, VWInfoWeb, T7Ocorrencias, T8Deslocamento, T8AUXDeslocamento
from app.forms import OcorrenciaForm, TransporteForm
from django.core.paginator import Paginator
import logging
from django.contrib import messages
from django.views.decorators.csrf import csrf_protect


def home(request):
    search = request.GET.get('search')

    if search:
        pedidos_list = PedidoAndamento.objects.filter(id_original__contains=search)
    else:
        pedidos_list = PedidoAndamento.objects.all().order_by('ordem_page')

    paginator = Paginator(pedidos_list, 20)
    page_number = request.GET.get('page')
    page_obj = paginator.get_page(page_number)

    return render(request, 'index.html', {'page_obj': page_obj})


def base(request, pk):
    data = {}

    vw_info_web = get_object_or_404(VWInfoWeb, id=pk)
    pedido_andamento = get_object_or_404(PedidoAndamento, id=pk)
    t1_pedidos = get_object_or_404(T1Pedidos, id=pk)

    data['db'] = vw_info_web
    data['dx'] = pedido_andamento
    data['dy'] = t1_pedidos

    try:
        t7_ocorrencias = T7Ocorrencias.objects.filter(id_pedido=vw_info_web.id_original)
        data['dz'] = t7_ocorrencias
    except T7Ocorrencias.DoesNotExist:

        pass

    return render(request, 'base.html', data)


def ocorrencia(request):
    data = {}
    data['form'] = OcorrenciaForm()
    return render(request, 'ocorrencia.html', data)

logger = logging.getLogger(__name__)
def create(request):
    form = OcorrenciaForm(request.POST or None)
    if form.is_valid():
        form.save()
        logger.info("Ocorrência salva com sucesso")
        success_message = 'Ocorrência salva com sucesso.'
        messages.success(request, success_message)
        return redirect('ocorrencia')

    logger.error("Formulário inválido: %s", form.errors)
    messages.error(request, 'Houve um erro ao salvar a ocorrência.')


def transporte(request, pk):
    data = {}
    data['db'] = T8AUXDeslocamento.objects.get(id=pk)
    data['dy'] = VWInfoWeb.objects.get(id=pk)
    data['dx'] = T8Deslocamento.objects.get(id=pk)
    data['form'] = TransporteForm(instance=data['db'])
    return render(request, 'transporte.html', data)


def update(request, pk):
    data = {}
    data['db'] = T8AUXDeslocamento.objects.get(id=pk)
    form = TransporteForm(request.POST or None, instance=data['db'])


    if request.method == 'POST':
        form = TransporteForm(request.POST, instance=data['db'])
        if form.is_valid():
            form.save()
            logger.info("Atualização salva com sucesso")
            success_message = 'Atualização salva com sucesso.'
            messages.success(request, success_message)
            return redirect('transporte', pk=data['db'].id)

    else:
        form = TransporteForm(instance=data['db'])

    logger.error("Formulário inválido: %s", form.errors)
    messages.error(request, 'Houve um erro ao salvar a atualização.')